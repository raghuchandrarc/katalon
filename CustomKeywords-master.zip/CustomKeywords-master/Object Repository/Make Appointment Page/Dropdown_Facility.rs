<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This is the page object for Dropdown Facility</description>
   <name>Dropdown_Facility</name>
   <tag></tag>
   <elementGuidId>56243a87-a3d9-4b89-9e0b-b0ba0a25bc88</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>.//*[@id='combo_facility']</value>
   </webElementProperties>
</WebElementEntity>
