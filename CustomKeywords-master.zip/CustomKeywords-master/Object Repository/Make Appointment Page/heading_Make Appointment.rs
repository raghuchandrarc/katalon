<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>heading_Make Appointment</name>
   <tag></tag>
   <elementGuidId>b0d8d04a-e6a3-4ab6-9575-6a46e78a0cdb</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>.//h2[text()='Make Appointment']</value>
   </webElementProperties>
</WebElementEntity>
